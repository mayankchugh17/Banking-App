import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;

@WebServlet("/DepositServlet")
public class DepositServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        double amount = Double.parseDouble(request.getParameter("amount"));
        HttpSession session = request.getSession();
        Integer accountId = (Integer) session.getAttribute("user_id");

        Connection conn = DatabaseConnection.getConnection();
        String sql = "UPDATE accounts SET balance = balance + ? WHERE account_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDouble(1, amount);
            stmt.setInt(2, accountId);
            int rowsUpdated = stmt.executeUpdate();

            if (rowsUpdated > 0) {
                // Log transaction
                sql = "INSERT INTO transactions (account_id, transaction_type, amount) VALUES (?, 'Deposit', ?)";
                try (PreparedStatement stmt2 = conn.prepareStatement(sql)) {
                    stmt2.setInt(1, accountId);
                    stmt2.setDouble(2, amount);
                    stmt2.executeUpdate();
                }

                // Update the balance in the session
                sql = "SELECT balance FROM accounts WHERE account_id = ?";
                try (PreparedStatement stmt3 = conn.prepareStatement(sql)) {
                    stmt3.setInt(1, accountId);
                    ResultSet rs = stmt3.executeQuery();
                    if (rs.next()) {
                        session.setAttribute("balance", rs.getDouble("balance"));
                    }
                }
                response.sendRedirect("dashboard.jsp");
            } else {
                // Handle the case where the update failed (optional)
                response.sendRedirect("dashboard.jsp?error=Deposit failed");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("dashboard.jsp?error=Database error during deposit");
        } finally {
            try { if (conn != null) conn.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }
}