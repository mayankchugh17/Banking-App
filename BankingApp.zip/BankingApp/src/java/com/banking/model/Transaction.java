package com.banking.model;

public class Transaction {
    private String type;
    private double amount;
    private java.sql.Timestamp date;

    // Constructor
    public Transaction(String type, double amount, java.sql.Timestamp date) {
        this.type = type;
        this.amount = amount;
        this.date = date;
    }

    // Getters
    public String getType() {
        return type;
    }

    public double getAmount() {
        return amount;
    }

    public java.sql.Timestamp getDate() {
        return date;
    }
}
