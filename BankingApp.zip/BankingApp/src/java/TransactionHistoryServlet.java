import com.banking.model.Transaction;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/TransactionHistoryServlet")
public class TransactionHistoryServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user_id") == null) {
            response.sendRedirect("index.jsp");
            return;
        }

        Integer accountId = (Integer) session.getAttribute("user_id");
        List<Transaction> transactionHistory = getTransactionHistory(accountId);

        // Debugging logs
        System.out.println("Account ID: " + accountId);
        System.out.println("Transaction History Size: " + (transactionHistory != null ? transactionHistory.size() : "null"));
        if (transactionHistory != null) {
            for (Transaction t : transactionHistory) {
                System.out.println("Type: " + t.getType() + ", Amount: " + t.getAmount() + ", Date: " + t.getDate());
            }
        }

        request.setAttribute("transactionHistory", transactionHistory);
        request.getRequestDispatcher("/transaction_history.jsp").forward(request, response);
    }

    private List<Transaction> getTransactionHistory(int accountId) {
        List<Transaction> history = new ArrayList<>();
        Connection conn = DatabaseConnection.getConnection();
        String sql = "SELECT transaction_type, amount, transaction_date FROM transactions WHERE account_id = ? ORDER BY transaction_date DESC";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, accountId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String type = rs.getString("transaction_type");
                double amount = rs.getDouble("amount");
                java.sql.Timestamp date = rs.getTimestamp("transaction_date");
                history.add(new Transaction(type, amount, date));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return history;
    }
}
